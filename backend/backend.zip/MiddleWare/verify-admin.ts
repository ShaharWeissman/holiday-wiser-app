
import { NextFunction, Request, Response } from "express";
import { UnauthorizedError } from "../Models/Clients-Errors";
import { verify } from "jsonwebtoken";
import cyber from "../Utils/cyber";

//
function verifyAdmin(request: Request, response: Response, next: NextFunction): void {

const authorizationHeader = request.header("authorization");

if (!authorizationHeader) {
    response.status(401).json({ error: "Missing authorization header" });
    return;
}
//extract token - (bearer - the token) the token first letter position is 7
const token = authorizationHeader?.substring(7);
//  ? , so the system wont fell if the user didnt sent token 

//verify the admin:
    cyber.verifyAdmin(token);

// we need to put the next(), or else the opeation will stuck
next();

}

export default verifyAdmin;
