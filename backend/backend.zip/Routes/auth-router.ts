import express, { Request, Response, Router, NextFunction } from "express";
import StatusCode from "../Models/status-code";
import AuthLogic from "../Logic/AuthLogic";
import UserModel from "../Models/UserModel";
import CredentialsModel from "../Models/creadentialsModel";

//create router part of the express
const router = express.Router();

//post router
router.post(
  "/signup",
  async (request: Request, response: Response, next: NextFunction) => {
    try {
      console.log(request.body);
      // get the user sent from front
      const user = new UserModel(request.body);
      user.validate();

      // add it to the sql database
      const token = await AuthLogic.signup(user);

      //response back the token itselef
      response.status(StatusCode.Created).json(token);
    } catch (err: any) {
      next(err);
    }
  }
);

//login router (always login=post)
router.post(
  "/login",
  async (request: Request, response: Response, next: NextFunction) => {
    try {
      // get the credentials :
      const credentials = new CredentialsModel(request.body);

      // the login:
      const token = await AuthLogic.login(credentials);

      //response back the token no need for "status(statusCode.eg)"
      response.json(token);
    } catch (err: any) {
      next(err);
    }
  }
);

export default router;
