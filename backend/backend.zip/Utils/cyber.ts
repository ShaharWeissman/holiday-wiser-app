import UserModel from "../Models/UserModel";
import jwt from "jsonwebtoken";
import { UnauthorizedError , ForbiddenError} from "../Models/Clients-Errors";
import RoleModel from "../Models/RoleModel";

// Secret key for token
const tokenSecretKey = "goPassword";

function getNewToken(user: UserModel): string {
  // Container for the object = user that is inside the token
  const container = { user };

  // When it will expire
  const options = { expiresIn: "2h" };

  // Token creation
  const token = jwt.sign(container, tokenSecretKey, options);
  // Return the token
  return token;
}

function verifyToken(token: string): void {
  if (!token) throw new UnauthorizedError("You are missing JWT token");

  try {
    console.log(jwt.verify(token, tokenSecretKey));
    jwt.verify(token, tokenSecretKey);
  } catch (err: any) {
    throw new UnauthorizedError(err.message);
  }
}


//verify the admin role
function verifyAdmin(token: string): void {
// verify the token
verifyToken(token);
//get container (the user is there)
const container = jwt.verify(token, tokenSecretKey) as {user: UserModel};
// take the user
const user = container.user;

//if its not admin
if (user.roleId !==  RoleModel.Admin) throw new ForbiddenError("you are not the ADMIN")

}

export default {
  getNewToken,
  verifyToken,
  verifyAdmin
};
