enum RoleModel {
  Admin =1,
  User
  }
  export default RoleModel;
  