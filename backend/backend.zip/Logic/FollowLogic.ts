import { OkPacket } from "mysql";
import dal_mysql from "../Utils/dal_mysql";
import FollowModel from "../Models/FollowModel";

const getAllFollowers = async (user_id: number) => {
  const sqlCommand = `SELECT   holiday_id AS holiday_id, user_id AS user_id FROM 
  follow`
  const followers = await dal_mysql.execute(sqlCommand);
  return followers;
};


const addFollower = async (newFollow: FollowModel) => {
  const sqlCommand = `INSERT INTO holiday.follows (user_id, holiday_id) VALUES ('${newFollow.user.id}', '${newFollow.holiday.id}');`;
  console.log(sqlCommand);
  const result = await dal_mysql.execute(sqlCommand);
  return result.insertId;
};



  const getUserFollows = async (user_id: number) => {
    console.log(`this user follow id${user_id}`);
    const sqlCommand =  `SELECT * FROM  followers WHERE user_id = ${user_id }`;
    const result =  await dal_mysql.execute(sqlCommand);
    return result;}

  const removeFollowerById = async (holiday_id: number) => {
    const sqlCommand = `DELETE FROM followers WHERE holiday_id = ${holiday_id}`;
  await dal_mysql.execute(sqlCommand);
};
  
export default {
  getAllFollowers,
  addFollower,
  getUserFollows,
  removeFollowerById
};
