class Config {
  public WebPort = 4000;
    public mySQLhost = "localhost";
    public mySQLuser = "root";
    public mySQLpass = "12345678";
    public mySQLport = 3306;
    public mySQLdatabase = "holiday";
    public readonly domainName = "http://localhost:" + this.WebPort;

  }
  
  const config = new Config();
  export default config;
  