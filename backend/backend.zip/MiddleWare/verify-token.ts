
import { NextFunction, Request, Response } from "express";
import { UnauthorizedError } from "../Models/Clients-Errors";
import { verify } from "jsonwebtoken";
import cyber from "../Utils/cyber";

// verify token vaild
function verifyToken(request: Request, response: Response, next: NextFunction): void {
//authorizion header text and how its display: bearer (space) the-token - 
// at postion of letter number 7 start the acutal token [after the word bearer]

const authorizationHeader = request.header("authorization");

if (!authorizationHeader) {
    response.status(401).json({ error: "Missing authorization header" });
    return;
}
//extract token - (bearer - the token) the token first letter position is 7
const token = authorizationHeader?.substring(7);
//  ? , so the system wont fell if the user didnt sent token 

//verify the token:
    cyber.verifyToken(token);

// we need to put the next(), or else the opeation will stuck
next();

}

export default verifyToken;
