import mysql, { OkPacket } from "mysql";
import config from "../Utils/Config";

// Creating a connection pool
const connection = mysql.createPool({
  host: config.mySQLhost,
  user: config.mySQLuser,
  password: config.mySQLpass,
  database: config.mySQLdatabase,
  port: config.mySQLport,
});

const execute = (sql: string): Promise<any> => {
  return new Promise<any>((resolve, reject) => {
    // Connection and execute the SQL command
    connection.query(sql, (err, res) => {
      if (err) {
        reject(err);
        return;
      }

      resolve(res);
    });
  });
};

export default { execute };