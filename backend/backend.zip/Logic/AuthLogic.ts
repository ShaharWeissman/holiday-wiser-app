
import { UnauthorizedError, ValidationError } from "../Models/Clients-Errors";
import RoleModel from "../Models/RoleModel";
import UserModel from "../Models/UserModel";
import CredentialsModel from "../Models/creadentialsModel";
import cyber from "../Utils/cyber";
import dal_mysql from "../Utils/dal_mysql";
import { OkPacket } from "mysql";

//the signup logic:
async function signup(user: UserModel): Promise<string> {
  try {
    // Validation:
    user.validate();

    //set the User as role
    user.roleId = RoleModel.User;
    
    // Check if email is already taken
    if (await isEmailTaken(user.email)) {
      throw new ValidationError(`Email: ${user.email} is already taken`);
    }

    // SQL command for  user
    const sqlCommand = `INSERT INTO users (first_name, last_name, email, password, roleId)
    VALUES ('${user.first_name}', '${user.last_name}', '${user.email}', '${user.password}', ${user.roleId})`;

    // Execute SQL command
    const info: OkPacket = await dal_mysql.execute(sqlCommand);

    // Set user's ID
    user.id = info.insertId;

    // Generate a new token
    const token =  cyber.getNewToken(user);

    // Return the token
    return token;
  } catch (error) {
    throw error;
  }
}


//function for the email check
async function isEmailTaken(email: string): Promise<boolean> {
  const sqlCommand = `SELECT COUNT(*) AS count FROM users WHERE email = '${email}'`;
  const result = await dal_mysql.execute(sqlCommand);
  const count = result[0].count;
  return count > 0;
}


//======the Login logic: we return string which is the token
async function login(credentials: CredentialsModel): Promise<string> {
  //validation
  credentials.validate();
//sql command
const sqlCommand = `SELECT * FROM users WHERE 
  email = '${credentials.email}' AND 
  password = '${credentials.password}'`;

  //execution
  const users = await dal_mysql.execute(sqlCommand);

// extract the user:
const user = users[0]

//if the user dosn't exist
if (!user) {
  throw new UnauthorizedError(" email or password are incorrect");
}
//generate jwt:
const token= cyber.getNewToken(user);

return token;

}




export default {
  signup,
  login,
};
