import express, { NextFunction, Request, Response } from "express";
import { Test } from "../Models/test";

const router = express.Router();

//http://loaclhost:4000/api/v1/checkOK

router.get ("/checkOk", async (  request: Request,response: Response, next: NextFunction) =>{
    let test=new Test("its fucking great")
    response.status(200).json(test);
}
);

router.get ("/checkBAD", async (  request: Request,response: Response, next: NextFunction) =>{
    let test=new Test("i hate this!")
    response.status(400).json(test);
}
);

router.post ("/checkOk", async (  request: Request,response: Response, next: NextFunction) =>{
    let test=new Test("all fine!")
    console.log(request.body);
    response.status(200).json(test);
}
);
router.post ("/checkBAD", async (  request: Request,response: Response, next: NextFunction) =>{
    let test=new Test("all shit!")
    response.status(400).json(test);
}
);

router.put ("/checkOk", async (  request: Request,response: Response, next: NextFunction) =>{
    let test=new Test("all isss fine!")
    response.status(200).json(test);
}
);
router.put ("/checkBAD", async (  request: Request,response: Response, next: NextFunction) =>{
    let test=new Test("all isss fine!")
    response.status(400).json(test);
}
);

router.delete 
("/checkOk", async (  request: Request,response: Response, next: NextFunction) =>{
    let test=new Test("all isss fine!")
    response.status(200).json(test);
}
);
router.delete 
("/checkBAD", async (  request: Request,response: Response, next: NextFunction) =>{
    let test=new Test("badddd")
    response.status(400).json(test);
}
);

export default router;