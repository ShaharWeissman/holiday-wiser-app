
import { NextFunction, Request, Response } from "express";
import { UnauthorizedError } from "../Models/Clients-Errors";

function dataGuard(request: Request, response: Response, next: NextFunction): void {
    
    const guardKey = "holiday-every-day";

    // If request don't have a doorman key value (maybe a hacker?):
    if(request.header("dataGuardKey") !== guardKey) {
        next(new UnauthorizedError("user is Unauthorized!"));
        return;
    }

    // Request containing the dataGuard key:
    next();
}

export default dataGuard;
